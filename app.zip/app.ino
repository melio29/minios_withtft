#include <lvgl.h>
#include <TFT_eSPI.h>
#include "ui.h"
volatile bool calculatorPressed = false;
 

TFT_eSPI tft = TFT_eSPI();
 

/**********************
 * LVGL Draw Buffer
 **********************/
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[480 * 20];

/**********************
 * Display Flush
 **********************/
void my_disp_flush(lv_disp_drv_t *disp,
                   const lv_area_t *area,
                   lv_color_t *color_p)
{
    uint32_t w = area->x2 - area->x1 + 1;
    uint32_t h = area->y2 - area->y1 + 1;

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t *)&color_p->full, w * h, true);
    tft.endWrite(); 

    lv_disp_flush_ready(disp);
}

/**********************
 * Touch Read
 **********************/
void my_touchpad_read(lv_indev_drv_t * indev_driver,
                      lv_indev_data_t * data)
{
    uint16_t x, y;

    bool touched = tft.getTouch(&x, &y);

    if (!touched)
    {
        data->state = LV_INDEV_STATE_RELEASED;
    }
    else
    {
        data->state = LV_INDEV_STATE_PRESSED;
        data->point.x = x;
        data->point.y = y;

        Serial.print("Touch : ");
        Serial.print(x);
        Serial.print(" , ");
        Serial.println(y);
    }
}

void setup()
{
    Serial.begin(115200);

    tft.init();
    tft.setRotation(1);

    lv_init();

    lv_disp_draw_buf_init(&draw_buf, buf, NULL, 480 * 20);

    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);

    disp_drv.hor_res = 480;
    disp_drv.ver_res = 320;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;

    lv_disp_drv_register(&disp_drv);

    /************* TOUCH *************/
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);

    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = my_touchpad_read;

    lv_indev_drv_register(&indev_drv);

    /************* UI *************/
    ui_init();

   

}

void loop()
{
    lv_timer_handler();
    delay(5);
    if (calculatorPressed)
{
    Serial.println("Calculator button clicked");
    calculatorPressed = false;
}
}